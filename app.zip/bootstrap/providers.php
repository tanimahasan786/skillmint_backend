<?php

return [
    App\Providers\AppServiceProvider::class,
    Tymon\JWTAuth\Providers\LaravelServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
    Vimeo\Laravel\VimeoServiceProvider::class,
     Barryvdh\DomPDF\ServiceProvider::class,
];
