// ck editor
CKEDITOR.replace('poster_1');




